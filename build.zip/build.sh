#!/usr/bin/env bash
set -euo pipefail

# Build the Docker image, prepare findings, and launch AFL++ against YAJL.
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
IMAGE_NAME="afl-yajl"
FINDINGS_DIR="$ROOT_DIR/findings"
CORE_PATTERN_FILE="/proc/sys/kernel/core_pattern"
ORIGINAL_CORE_PATTERN=""
CORE_PATTERN_CHANGED=0

# core_pattern is a *host-wide* kernel setting, not a Dockerfile setting.
write_core_pattern() {
  local value="$1"
  local mode="${2:-interactive}"

  if (( EUID == 0 )); then
    printf '%s\n' "$value" > "$CORE_PATTERN_FILE"
  elif [[ "$mode" == "noninteractive" ]]; then
    printf '%s\n' "$value" | sudo -n tee "$CORE_PATTERN_FILE" >/dev/null
  else
    printf '%s\n' "$value" | sudo tee "$CORE_PATTERN_FILE" >/dev/null
  fi
}

restore_core_pattern() {
  if (( CORE_PATTERN_CHANGED == 0 )); then
    return 0
  fi

  # Do not overwrite a setting another process might have changed.
  local current
  current="$(cat "$CORE_PATTERN_FILE" 2>/dev/null || true)"
  if [[ "$current" != "core" ]]; then
    echo "[WARN] kernel.core_pattern changed externally; leaving it as-is." >&2
    return 0
  fi

  # Avoid hanging at shutdown if the sudo credential cache has expired.
  if write_core_pattern "$ORIGINAL_CORE_PATTERN" noninteractive; then
    echo "[INFO] Restored original kernel.core_pattern." >&2
  else
    echo "[WARN] Could not restore kernel.core_pattern automatically." >&2
    printf '[WARN] Restore it manually: sudo sysctl -w %q\n' \
      "kernel.core_pattern=$ORIGINAL_CORE_PATTERN" >&2
  fi
}
trap restore_core_pattern EXIT

if ! command -v docker >/dev/null 2>&1; then
  echo "Error: Docker is not installed or not in PATH." >&2
  exit 1
fi
if [[ ! -f "$ROOT_DIR/Dockerfile" ]]; then
  echo "Error: Dockerfile not found in $ROOT_DIR" >&2
  exit 1
fi

echo "[1/4] Building $IMAGE_NAME (host networking for DNS)..."
docker build \
  --network=host \
  --progress=plain \
  -f "$ROOT_DIR/Dockerfile" \
  -t "$IMAGE_NAME" \
  "$ROOT_DIR"

echo "[2/4] Preparing findings..."
mkdir -p "$FINDINGS_DIR"

INPUT_DIR="/opt/seeds"
if [[ -f "$FINDINGS_DIR/default/fuzzer_stats" ]]; then
  INPUT_DIR="-"
  echo "Existing campaign found: resuming with -i -"
else
  echo "Starting a new campaign with /opt/seeds"
fi

echo "[3/4] Checking host kernel.core_pattern..."
if [[ ! -r "$CORE_PATTERN_FILE" ]]; then
  echo "Error: cannot read $CORE_PATTERN_FILE (Linux host required)." >&2
  exit 1
fi
ORIGINAL_CORE_PATTERN="$(cat "$CORE_PATTERN_FILE")"
if [[ "$ORIGINAL_CORE_PATTERN" == \|* ]]; then
  echo "core_pattern uses a crash handler; AFL++ requires a file-based pattern."
  echo "Temporarily setting kernel.core_pattern=core (sudo may ask for a password)..."
  if ! write_core_pattern "core"; then
    echo "Error: failed to change host kernel.core_pattern." >&2
    exit 1
  fi
  CORE_PATTERN_CHANGED=1
  if [[ "$(cat "$CORE_PATTERN_FILE")" != "core" ]]; then
    echo "Error: kernel.core_pattern did not change to 'core'." >&2
    exit 1
  fi
else
  echo "kernel.core_pattern is already compatible: $ORIGINAL_CORE_PATTERN"
fi

echo "[4/4] Starting AFL++ (press Ctrl+C to stop)..."

DOCKER_ARGS=(run --rm -i)
if [[ -t 0 && -t 1 ]]; then
  DOCKER_ARGS+=(-t)
else
  DOCKER_ARGS+=(-e AFL_NO_UI=1)
fi

DOCKER_ARGS+=(
  --user "$(id -u):$(id -g)"
  -e AFL_SKIP_CPUFREQ=1
  -e AFL_NO_AFFINITY=1
  -v "$FINDINGS_DIR:/results"
  "$IMAGE_NAME"
  afl-fuzz -i "$INPUT_DIR" -o /results -- json_verify -q
)

# No 'exec' here: the EXIT trap needs to restore the host setting afterwards.
docker "${DOCKER_ARGS[@]}"